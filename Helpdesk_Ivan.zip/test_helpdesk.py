import json
import unittest
from unittest.mock import Mock

from agent import (
    RESPOSTA_SEM_ORIENTACAO,
    atender,
    inferir_chat,
    responder_chat,
    triar,
)
from workspace import ler_documento, registrar_chamado


class HelpDeskTest(unittest.TestCase):
    def test_inferir_chat_envia_historico_ao_groq(self):
        cliente = Mock()
        cliente.chat.completions.create.return_value.choices = [
            Mock(
                message=Mock(
                    content=(
                        '{"acao":"perguntar","mensagem":"Qual mensagem aparece?",'
                        '"passos":[],"evidencia":""}'
                    )
                )
            )
        ]
        historico = [
            {"role": "user", "content": "Meu telefone não funciona."},
            {"role": "assistant", "content": "É um telefone IP?"},
            {"role": "user", "content": "Sim."},
        ]

        resultado = inferir_chat(cliente, "Telefone IP\nConfira o visor.", historico)

        conteudo = json.loads(
            cliente.chat.completions.create.call_args.kwargs["messages"][1]["content"]
        )
        self.assertEqual(conteudo["historico"], historico)
        self.assertEqual(resultado["acao"], "perguntar")

    def test_inferir_chat_rejeita_resposta_vazia(self):
        cliente = Mock()
        cliente.chat.completions.create.return_value.choices = [
            Mock(message=Mock(content=None))
        ]

        with self.assertRaisesRegex(ValueError, "resposta vazia"):
            inferir_chat(cliente, "Base", [{"role": "user", "content": "Ajuda"}])

    def test_chat_formata_orientacao_com_secao_evidencia(self):
        base = (
            "BASE FICTÍCIA — HELPDESK\n"
            "Wi-Fi de visitantes\n"
            "No menu de redes, selecione IJ3-Visitantes.\n"
        )
        historico = [{"role": "user", "content": "Qual rede devo usar?"}]
        consultar = Mock(return_value={
            "acao": "orientar",
            "mensagem": "Conecte-se à rede de visitantes.",
            "passos": ["Abra o menu de redes.", "Selecione IJ3-Visitantes."],
            "evidencia": "selecione IJ3-Visitantes",
        })

        resposta = responder_chat(lambda: base, consultar, historico)

        self.assertEqual(resposta["acao"], "orientar")
        self.assertEqual(resposta["secao"], "Wi-Fi de visitantes")
        self.assertEqual(len(resposta["passos"]), 2)
        consultar.assert_called_once_with(base.strip(), historico)

    def test_chat_aceita_hifen_unicode_na_evidencia_e_localiza_secao(self):
        base = (
            "BASE FICTÍCIA — HELPDESK\n"
            "Computador sem acesso à internet\n"
            "Confira se o Wi-Fi está ligado e se o computador está conectado "
            "à rede correta.\n"
        )
        resposta_modelo = {
            "acao": "orientar",
            "mensagem": "Confira a conexão de rede.",
            "passos": ["Confira se o Wi-Fi está ligado."],
            "evidencia": (
                "Computador sem acesso à internet\n"
                "Confira se o Wi‑Fi está ligado e se o computador está conectado "
                "à rede correta."
            ),
        }

        resposta = responder_chat(
            lambda: base,
            lambda *_: resposta_modelo,
            [{"role": "user", "content": "Sem acesso a internet"}],
        )

        self.assertEqual(resposta["acao"], "orientar")
        self.assertEqual(resposta["secao"], "Computador sem acesso à internet")

    def test_chat_pede_detalhe_sem_inventar_passos(self):
        consultar = Mock(return_value={
            "acao": "perguntar",
            "mensagem": "Qual mensagem aparece no visor do telefone?",
            "passos": [],
            "evidencia": "",
        })

        resposta = responder_chat(
            lambda: "Telefone IP\nConfira o ícone de rede no visor.",
            consultar,
            [{"role": "user", "content": "Meu telefone não funciona."}],
        )

        self.assertEqual(resposta["acao"], "perguntar")
        self.assertEqual(resposta["passos"], [])

    def test_chat_sem_orientacao_retorna_mensagem_padrao(self):
        resposta = responder_chat(
            lambda: "Wi-Fi de visitantes\nSelecione IJ3-Visitantes.",
            lambda *_: {
                "acao": "sem_orientacao",
                "mensagem": "texto livre do modelo",
                "passos": [],
                "evidencia": "",
            },
            [{"role": "user", "content": "Como configurar um servidor SAP?"}],
        )

        self.assertEqual(resposta["mensagem"], RESPOSTA_SEM_ORIENTACAO)
        self.assertEqual(resposta["passos"], [])

    def test_chat_rejeita_evidencia_ausente_da_base(self):
        with self.assertRaises(ValueError):
            responder_chat(
                lambda: "Wi-Fi de visitantes\nSelecione IJ3-Visitantes.",
                lambda *_: {
                    "acao": "orientar",
                    "mensagem": "Reinicie o roteador.",
                    "passos": ["Reinicie o roteador."],
                    "evidencia": "Reinicie o roteador",
                },
                [{"role": "user", "content": "A internet não funciona."}],
            )

    def test_confirmacao_controla_abertura(self):
        resultado = {"acao": "orientar", "mensagem": "Selecione a rede.",
                     "evidencia": "IJ3-Visitantes"}
        for resolveu in (True, False):
            with self.subTest(resolveu=resolveu):
                gravar = Mock()
                atender(lambda: "Rede IJ3-Visitantes", lambda *_: resultado,
                        gravar, "Ana", "TI", "Wi-Fi", lambda _: resolveu)
                if resolveu:
                    gravar.assert_not_called()
                else:
                    gravar.assert_called_once_with(
                        "Ana", "TI", "Wi-Fi", "A orientação não resolveu o problema."
                    )

    def test_evidencia_inventada_e_falhas_escalam(self):
        for ler, modelo in (
            (lambda: "base", lambda *_: {"acao": "orientar", "mensagem": "X",
                                         "evidencia": "inventada"}),
            (Mock(side_effect=TimeoutError), Mock()),
            (lambda: "base", Mock(side_effect=TimeoutError)),
            (lambda: "  ", Mock()),
        ):
            with self.subTest(ler=ler, modelo=modelo):
                self.assertFalse(triar(ler, modelo, "dúvida")[0])

    def test_leitura_de_abas_e_tabelas(self):
        docs = Mock()
        corpo = {"table": {"tableRows": [{"tableCells": [
            {"content": [{"paragraph": {"elements": [{"textRun": {"content": "Wi-Fi"}}]}}]}
        ]}]}}
        docs.documents().get().execute.return_value = {
            "tabs": [{"childTabs": [{"documentTab": {"body": corpo}}]}]
        }
        self.assertEqual(ler_documento(docs, "doc").strip(), "Wi-Fi")

    def test_gravacao_literal_e_confirmacao(self):
        sheets = Mock()
        append = sheets.spreadsheets().values().append
        append.return_value.execute.return_value = {"updates": {"updatedRows": 1}}
        mensagem = registrar_chamado(sheets, "id", "=1+1", "TI", "Dúvida", "Sem base")
        self.assertIn("Chamado aberto", mensagem)
        self.assertEqual(append.call_args.kwargs["valueInputOption"], "RAW")
        linha = append.call_args.kwargs["body"]["values"][0]
        self.assertEqual(linha[2:], ["=1+1", "TI", "Dúvida", "Sem base", "Aberto"])
        self.assertIn(linha[0], mensagem)
        append.return_value.execute.side_effect = TimeoutError
        self.assertIn("Gravação não confirmada",
                      registrar_chamado(sheets, "id", "Ana", "TI", "Dúvida", "Sem base"))
