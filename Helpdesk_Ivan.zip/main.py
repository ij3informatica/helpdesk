import os
from functools import partial

from dotenv import load_dotenv
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from groq import Groq

from agent import atender, inferir
from workspace import ler_documento, registrar_chamado


def main():
    load_dotenv()
    chaves = ("GOOGLE_APPLICATION_CREDENTIALS", "GOOGLE_DOC_ID",
              "GOOGLE_SHEET_ID", "GROQ_API_KEY")
    faltantes = [chave for chave in chaves if not os.getenv(chave)]
    if faltantes:
        raise SystemExit("Preencha no .env: " + ", ".join(faltantes))

    try:
        credenciais = Credentials.from_service_account_file(
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"],
            scopes=["https://www.googleapis.com/auth/documents.readonly",
                    "https://www.googleapis.com/auth/spreadsheets"],
        )
        docs = build("docs", "v1", credentials=credenciais)
        sheets = build("sheets", "v4", credentials=credenciais)
        cliente = Groq(timeout=20.0, max_retries=0)
    except (OSError, ValueError):
        raise SystemExit("Confira o caminho e o formato do JSON da conta de serviço.")

    print("HelpDesk | Suporte de TI")
    print("Use dados fictícios no piloto. Nunca informe senhas ou códigos.")
    nome = input("Nome: ").strip()
    setor = input("Setor: ").strip()
    pergunta = input("Descreva o problema: ").strip()
    if not all((nome, setor, pergunta)):
        raise SystemExit("Preencha nome, setor e descrição.")
    if len(nome) > 120 or len(setor) > 120 or len(pergunta) > 3000:
        raise SystemExit("Use até 120 caracteres para nome e setor e 3000 para a descrição.")

    def confirmar(orientacao):
        print(orientacao)
        while True:
            resposta = input("A orientação resolveu? [s/n] ").strip().lower()
            if resposta in {"s", "n"}:
                return resposta == "s"

    print(atender(
        partial(ler_documento, docs, os.environ["GOOGLE_DOC_ID"]),
        partial(inferir, cliente),
        partial(registrar_chamado, sheets, os.environ["GOOGLE_SHEET_ID"]),
        nome, setor, pergunta, confirmar,
    ))


if __name__ == "__main__":
    main()
