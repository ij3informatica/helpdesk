from datetime import datetime
from uuid import uuid4


def ler_documento(docs, documento_id):
    documento = docs.documents().get(
        documentId=documento_id,
        includeTabsContent=True,
        suggestionsViewMode="PREVIEW_WITHOUT_SUGGESTIONS",
    ).execute()

    def trechos(elemento):
        if isinstance(elemento, dict):
            if "textRun" in elemento:
                yield elemento["textRun"].get("content", "")
            else:
                for valor in elemento.values():
                    yield from trechos(valor)
        elif isinstance(elemento, list):
            for item in elemento:
                yield from trechos(item)

    def ler_abas(abas):
        for aba in abas:
            yield "".join(trechos(aba.get("documentTab", {}).get("body", {})))
            yield from ler_abas(aba.get("childTabs", []))

    return "\n".join(ler_abas(documento.get("tabs", [])))


def registrar_chamado(sheets, planilha_id, nome, setor, pergunta, motivo):
    protocolo = f"HD-{uuid4().hex[:12].upper()}"
    data = datetime.now().astimezone().isoformat(timespec="seconds")
    try:
        resposta = sheets.spreadsheets().values().append(
            spreadsheetId=planilha_id,
            range="'Chamados'!A:G",
            valueInputOption="RAW",
            insertDataOption="INSERT_ROWS",
            body={"values": [[protocolo, data, nome, setor, pergunta, motivo, "Aberto"]]},
        ).execute(num_retries=0)
        if resposta.get("updates", {}).get("updatedRows") != 1:
            raise RuntimeError("Gravação sem confirmação")
    except Exception:
        return (
            f"Gravação não confirmada. Peça à TI para buscar {protocolo} "
            "na planilha antes de reenviar."
        )
    return f"Chamado aberto. Protocolo: {protocolo}"
