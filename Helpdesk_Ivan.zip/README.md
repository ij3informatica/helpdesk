# HelpDesk | Aula 05

Aplicação de atendimento pelo navegador com Streamlit. O chat consulta a base de conhecimento no Google Docs e usa o GPT-OSS-20B via Groq para responder com orientações apoiadas por trechos da documentação. Quando não há orientação aplicável, um chamado é registrado no Google Sheets. A interface usa tons de azul; o fluxo original de terminal continua disponível.

## 1. Prepare os arquivos do Google

1. Crie um Google Docs chamado **Base de Conhecimento HelpDesk** e cole o conteúdo de `base-exemplo.txt`.
2. Crie uma planilha **Controle HelpDesk**, renomeie a aba para **Chamados** e cole a linha abaixo em A1 (os campos estão separados por tabulação).

```text
Protocolo	Data/hora	Nome	Setor	Descrição	Motivo da abertura	Status
```

3. Copie os IDs das URLs. Em ambos os arquivos o ID está entre `/d/` e a próxima barra. No Sheets, o número `gid` identifica a aba e não deve ser usado como ID da planilha.

## 2. Configure o acesso

1. No [Google Cloud Console](https://console.cloud.google.com/), crie ou selecione um projeto e habilite **Google Docs API** e **Google Sheets API**.
2. Em **IAM e administrador → Contas de serviço**, crie uma conta de serviço. Se a política da organização permitir, gere uma chave JSON em **Chaves** e salve-a como `credenciais.json` na pasta do projeto. Se a política bloquear a chave ou o compartilhamento, peça ao administrador uma configuração aprovada.
3. Compartilhe o Docs como **Leitor** e o Sheets como **Editor** com o e-mail `client_email` do JSON. As permissões são nos arquivos do Google Workspace.
4. Gere a chave em [Groq Console](https://console.groq.com/keys). Copie `.env.example` para `.env` e preencha `GOOGLE_DOC_ID`, `GOOGLE_SHEET_ID` e `GROQ_API_KEY`. Use o caminho do JSON em `GOOGLE_APPLICATION_CREDENTIALS`. Mantenha as credenciais fora do Git.

## 3. Abra no navegador

Extraia o ZIP e abra a pasta `HelpDesk`. No PowerShell, instale as dependências:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Se `.env` já existir, não o sobrescreva. Preencha-o conforme a seção anterior e inicie o Streamlit:

```powershell
.\.venv\Scripts\streamlit.exe run app.py
```

O navegador abrirá em `http://localhost:8501`. Para parar o servidor, pressione `Ctrl+C` no terminal. O app precisa alcançar as APIs do Google e da Groq; mantenha `.env` e `credenciais.json` privados e fora do Git.

Para usar o fluxo antigo no terminal, execute `.\.venv\Scripts\python.exe main.py`.

## 4. Use o chat

- `app.py` exibe o chat inicial e mantém o histórico durante a sessão. Se faltarem detalhes, o assistente pode pedir uma informação adicional e considerar as mensagens anteriores.
- Respostas orientativas mostram passos e a seção da base correspondente quando identificada. A aplicação exige uma evidência verificável presente no Google Docs antes de exibir os passos, normalizando diferenças tipográficas de hifens e espaços.
- Nome e setor são obrigatórios: o campo de pergunta permanece desabilitado até ambos serem preenchidos. Esses dados são incluídos nos chamados registrados no Google Sheets.
- Se não houver orientação aplicável, o chat informa que é necessário contatar o suporte e registra a conversa no Google Sheets.
- Depois de uma orientação, use **Sim, resolveu** para encerrar ou **Não resolveu** para abrir um chamado no Sheets.
- Se a consulta ao Google Docs falhar, o chat informa que a base está indisponível; se a Groq falhar ou uma resposta não puder ser validada, exibe uma mensagem apropriada. Os casos recuperáveis oferecem **Tentar novamente**.
- `main.py` continua disponível para o fluxo original pelo terminal.
- `workspace.py` lê o corpo das abas do Docs e registra uma linha com status **Aberto** no Sheets. Os valores são gravados como dados brutos, inclusive quando começam com sinal de igual.
- `agent.py` envia o histórico e a base ao modelo, exige evidência literal para mostrar orientações e mantém a triagem original usada por `main.py`.

## 5. Teste o chat

Com as integrações configuradas e o Streamlit iniciado:

1. Para testar uma resposta presente em `base-exemplo.txt` (ou no Docs sincronizado), pergunte: **“Como conecto ao Wi-Fi de visitantes?”**. A resposta esperada inclui a seção **Wi-Fi de visitantes** e passos baseados na documentação.
2. Para testar um assunto não coberto, pergunte: **“Como configuro um servidor SAP?”**. O chat deve informar que não encontrou orientação e abrir um chamado no Sheets.
3. Para testar esclarecimento e contexto, pergunte algo incompleto, como **“Meu telefone não funciona”**, e responda à pergunta complementar no mesmo chat.

A pergunta, o histórico da conversa e o texto integral da base são enviados à Groq. Use documentação fictícia no piloto e valide a política de dados antes de usar conteúdo interno.

Referências oficiais: [Groq Structured Outputs](https://console.groq.com/docs/structured-outputs), [Docs API](https://developers.google.com/workspace/docs/api/reference/rest/v1/documents/get) e [Sheets API](https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets.values/append).
