import os
from functools import partial
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
from google.auth.exceptions import GoogleAuthError
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from groq import APIError, Groq
from httplib2 import HttpLib2Error

from agent import inferir_chat, responder_chat
from workspace import ler_documento, registrar_chamado


ROOT = Path(__file__).resolve().parent
REQUIRED_ENV = (
    "GOOGLE_APPLICATION_CREDENTIALS",
    "GOOGLE_DOC_ID",
    "GOOGLE_SHEET_ID",
    "GROQ_API_KEY",
)
CHAT_UNAVAILABLE = (
    "A base de conhecimento está indisponível no momento. "
    "Tente novamente em instantes."
)
MODEL_UNAVAILABLE = (
    "Não foi possível gerar uma resposta no momento. Tente novamente em instantes."
)
INVALID_RESPONSE = (
    "Não foi possível validar a resposta com a base de conhecimento. "
    "Tente novamente."
)
INTEGRATION_ERRORS = (
    APIError,
    GoogleAuthError,
    HttpError,
    HttpLib2Error,
    OSError,
    ValueError,
)


@st.cache_resource
def criar_clientes(caminho_credenciais):
    credenciais = Credentials.from_service_account_file(
        caminho_credenciais,
        scopes=[
            "https://www.googleapis.com/auth/documents.readonly",
            "https://www.googleapis.com/auth/spreadsheets",
        ],
    )
    docs = build("docs", "v1", credentials=credenciais)
    sheets = build("sheets", "v4", credentials=credenciais)
    groq = Groq(timeout=20.0, max_retries=0)
    return docs, sheets, groq


def carregar_estilos():
    css = (ROOT / ".streamlit" / "style.css").read_text(encoding="utf-8")
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def obter_caminho_credenciais():
    caminho = Path(os.environ["GOOGLE_APPLICATION_CREDENTIALS"]).expanduser()
    return caminho if caminho.is_absolute() else ROOT / caminho


def montar_mensagem_assistente(resposta):
    if resposta["acao"] == "orientar":
        partes = ["**Sugestão de solução**", resposta["mensagem"]]
        if resposta["secao"]:
            partes.append(f"Seção: **{resposta['secao']}**")
        partes.extend(
            f"{indice}. {passo}"
            for indice, passo in enumerate(resposta["passos"], start=1)
        )
        return "\n\n".join(partes)
    return resposta["mensagem"]


def abrir_chamado(sheets, historico, nome, setor, motivo):
    nome = nome.strip()
    setor = setor.strip()
    if not nome or not setor:
        raise ValueError("Nome e setor são obrigatórios para abrir um chamado.")
    descricao = "\n".join(
        mensagem["content"]
        for mensagem in historico
        if mensagem["role"] == "user"
    )
    return registrar_chamado(
        sheets,
        os.environ["GOOGLE_SHEET_ID"],
        nome,
        setor,
        descricao,
        motivo,
    )


def registrar_orientacao_nao_resolvida(indice, nome, setor):
    historico = st.session_state["chat_history"]
    mensagem = historico[indice]
    mensagem["resolucao"] = "nao_resolvido"
    try:
        with st.spinner("Abrindo chamado para o suporte…"):
            caminho_credenciais = obter_caminho_credenciais().resolve()
            _, sheets, _ = criar_clientes(str(caminho_credenciais))
            mensagem["ticket"] = abrir_chamado(
                sheets,
                historico[:indice],
                nome,
                setor,
                "A orientação não resolveu o problema.",
            )
    except INTEGRATION_ERRORS:
        mensagem["erro_chamado"] = True


def registrar_falha_chat(mensagem, erro):
    st.session_state["chat_history"].append(
        {
            "role": "assistant",
            "content": mensagem,
            "retry": True,
            "diagnostico": type(erro).__name__,
        }
    )


def gerar_resposta_chat(nome, setor):
    historico = st.session_state["chat_history"]
    try:
        with st.spinner("Consultando a base de conhecimento…"):
            caminho_credenciais = obter_caminho_credenciais().resolve()
            docs, sheets, groq = criar_clientes(str(caminho_credenciais))
            base = ler_documento(docs, os.environ["GOOGLE_DOC_ID"])
            if not base.strip():
                raise ValueError("O documento de conhecimento está vazio.")
    except INTEGRATION_ERRORS as erro:
        registrar_falha_chat(CHAT_UNAVAILABLE, erro)
        return

    try:
        with st.spinner("Consultando a base de conhecimento…"):
            resposta = responder_chat(
                lambda: base,
                partial(inferir_chat, groq),
                [
                    {"role": mensagem["role"], "content": mensagem["content"]}
                    for mensagem in historico
                    if not mensagem.get("retry")
                ],
            )
    except APIError as erro:
        registrar_falha_chat(MODEL_UNAVAILABLE, erro)
        return
    except (ValueError, KeyError, TypeError, IndexError) as erro:
        registrar_falha_chat(INVALID_RESPONSE, erro)
        return

    mensagem = montar_mensagem_assistente(resposta)
    item = {
        "role": "assistant",
        "content": mensagem,
        "acao": resposta["acao"],
    }
    if resposta["acao"] == "sem_orientacao":
        item["ticket"] = abrir_chamado(
            sheets,
            historico,
            nome,
            setor,
            "Não foi encontrada orientação aplicável na base de conhecimento.",
        )
    historico.append(item)


def main():
    load_dotenv(ROOT / ".env")
    st.set_page_config(
        page_title="HelpDesk — Como podemos ajudar?",
        page_icon="🔹",
        layout="wide",
    )
    carregar_estilos()

    faltantes = [chave for chave in REQUIRED_ENV if not os.getenv(chave)]
    caminho_configurado = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "")
    caminho_credenciais = (
        obter_caminho_credenciais() if caminho_configurado else None
    )
    credenciais_disponiveis = (
        caminho_credenciais is not None and caminho_credenciais.is_file()
    )
    configurado = not faltantes and credenciais_disponiveis

    with st.sidebar:
        st.markdown('<div class="brand-mark">HELPDESK</div>', unsafe_allow_html=True)
        if st.button("Novo atendimento", use_container_width=True):
            st.session_state["chat_history"] = []
            st.rerun()

    st.markdown('<div class="eyebrow">Central de atendimento</div>', unsafe_allow_html=True)
    st.title("HelpDesk — Como podemos ajudar?")
    st.markdown(
        '<p class="page-subtitle">Consulte a base de conhecimento para encontrar '
        "uma orientação ou entre em contato com o suporte.</p>",
        unsafe_allow_html=True,
    )

    nome_col, setor_col = st.columns(2)
    with nome_col:
        nome = st.text_input(
            "Nome (obrigatório)",
            max_chars=120,
            key="nome_chamado",
            disabled=not configurado,
        )
    with setor_col:
        setor = st.text_input(
            "Setor (obrigatório)",
            max_chars=120,
            key="setor_chamado",
            disabled=not configurado,
        )
    dados_atendimento_validos = bool(nome.strip() and setor.strip())
    if configurado and not dados_atendimento_validos:
        st.info("Informe seu nome e setor para habilitar o campo de pergunta.")

    if not configurado:
        if faltantes:
            st.error("Configure no arquivo .env: " + ", ".join(faltantes))
        if caminho_configurado and not credenciais_disponiveis:
            st.error(
                "O arquivo indicado em GOOGLE_APPLICATION_CREDENTIALS não foi "
                "encontrado. Confira o caminho no arquivo .env."
            )

    historico = st.session_state.setdefault("chat_history", [])
    for indice, mensagem in enumerate(historico):
        with st.chat_message(mensagem["role"]):
            st.markdown(mensagem["content"])
            if mensagem.get("diagnostico"):
                st.caption(
                    "Detalhe técnico: " + mensagem["diagnostico"]
                )
            if mensagem.get("ticket") and mensagem.get("acao") != "orientar":
                if mensagem["ticket"].startswith("Chamado aberto."):
                    st.success(mensagem["ticket"])
                else:
                    st.warning(mensagem["ticket"])
            if mensagem.get("acao") == "orientar":
                if mensagem.get("resolucao") == "resolvido":
                    st.success("Que bom! Atendimento concluído.")
                elif mensagem.get("ticket"):
                    if mensagem["ticket"].startswith("Chamado aberto."):
                        st.success(mensagem["ticket"])
                    else:
                        st.warning(mensagem["ticket"])
                elif mensagem.get("erro_chamado"):
                    st.error("Não foi possível abrir o chamado. Tente novamente.")
                    if st.button("Tentar abrir chamado", key=f"retry_ticket_{indice}"):
                        registrar_orientacao_nao_resolvida(indice, nome, setor)
                        st.rerun()
                else:
                    resolveu, nao_resolveu = st.columns(2)
                    if resolveu.button(
                        "Sim, resolveu", key=f"resolved_{indice}"
                    ):
                        mensagem["resolucao"] = "resolvido"
                        st.rerun()
                    if nao_resolveu.button(
                        "Não resolveu", key=f"unresolved_{indice}"
                    ):
                        registrar_orientacao_nao_resolvida(indice, nome, setor)
                        st.rerun()

    if historico and historico[-1].get("retry"):
        if st.button("Tentar novamente", type="primary"):
            historico.pop()
            gerar_resposta_chat(nome, setor)
            st.rerun()

    nova_mensagem = st.chat_input(
        "Descreva o problema que você está enfrentando",
        max_chars=3000,
        disabled=not configurado or not dados_atendimento_validos,
    )
    if nova_mensagem and nova_mensagem.strip():
        if not dados_atendimento_validos:
            st.error("Preencha nome e setor antes de enviar sua pergunta.")
            st.stop()
        historico.append({"role": "user", "content": nova_mensagem.strip()})
        with st.chat_message("user"):
            st.markdown(nova_mensagem.strip())
        gerar_resposta_chat(nome, setor)
        st.rerun()


if __name__ == "__main__":
    main()
